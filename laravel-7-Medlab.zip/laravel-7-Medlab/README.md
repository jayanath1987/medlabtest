Require PHP 7
Update for Laravel version 7x

Configure database in .env file

DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=laravel
DB_USERNAME=root
DB_PASSWORD=root@123

Step 3:
php artisan migrate 

Step 4:
php artisan serve 

Step 5: 
http://127.0.0.1:8000/



